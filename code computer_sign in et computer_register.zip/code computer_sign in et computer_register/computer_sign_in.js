const loginButton = document.getElementById("login");
const registerButton = document.getElementById("register");

loginButton.addEventListener('click', function(event) {
  //event.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  // Code pour la validation de l'email et du mot de passe
  // Code pour la connexion
  console.log(" LOG IN: " + email + " / " + password);

  // code pour la connexion
});

registerButton.addEventListener('click', function(event) {
  //event.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  // Code pour la validation de l'email et du mot de passe
  // Code pour l'inscription
  console.log("REGISTER : " + email + " / " + password);
  // code pour l'inscription
});

function redirectToRegisterPage() {
  window.location.href = "computer_register.html";
}