const registerButton = document.getElementById("register");

loginButton.addEventListener('click', function(event) {
  //event.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const name = document.getElementById("name").value;
  const surname = document.getElementById("surname").value;
  const location = document.getElementById("location").value;
  // Code pour la validation de l'email, du mot de passe, du nom, du prénom et de la localisation

  // Code pour la connexion
  console.log(" LOG IN: " + email + " / " + password + " / " + name + " / " + surname + " / " + location);
  // code pour la connexion
});

registerButton.addEventListener('click', function(event) {
  //event.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const name = document.getElementById("name").value;
  const surname = document.getElementById("surname").value;
  const location = document.getElementById("location").value;
  // Code pour la validation de l'email, du mot de passe, du nom, du prénom et de la localisation
  
  // Code pour l'inscription
  console.log("REGISTER : " + email + " / " + password + " / " + name + " / " + surname + " / " + location);
  // code pour l'inscription
});